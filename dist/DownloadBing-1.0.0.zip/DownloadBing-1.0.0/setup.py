from distutils.core import setup
setup(
 name='DownloadBing',  #这个是最终打包的文件名
 version='1.0.0',
 py_modules=['download'], #要打包哪些，.py文件，
 )